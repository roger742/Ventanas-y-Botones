/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ventanaprincipal;

/**
 *
 * @author jairs
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class VentanaPrincipal extends JFrame {
    public VentanaPrincipal() {
        // Configuración de la ventana principal
        setTitle("Ventana Principal");
        setSize(800, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(2, 2)); // Diseño en cuadrícula 2x2
        
        // Creación de botones
        JButton boton1 = new JButton("Botón 1");
        JButton boton2 = new JButton("Botón 2");
        JButton boton3 = new JButton("Botón 3");
        JButton boton4 = new JButton("Botón 4");
        
        // Agregar eventos a los botones
        boton1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirVentana("Ventana 1");
            }
        });
        
        boton2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirVentana("Ventana 2");
            }
        });
        
        boton3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirVentana("Ventana 3");
            }
        });
        
        boton4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                abrirVentana("Ventana 4");
            }
        });
        
        // Agregar botones a la ventana
        add(boton1);
        add(boton2);
        add(boton3);
        add(boton4);
    }
    
    // Método para abrir una nueva ventana con un título específico
    private void abrirVentana(String titulo) {
        JFrame nuevaVentana = new JFrame();
        nuevaVentana.setTitle(titulo);
        nuevaVentana.setSize(500, 250);
        nuevaVentana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        nuevaVentana.setLocationRelativeTo(null);
        nuevaVentana.setVisible(true);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }
}


